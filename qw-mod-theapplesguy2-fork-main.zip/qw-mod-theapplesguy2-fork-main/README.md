# QW Mod
Mod for the rping server, QW.

Adds a shitload of stuff, focused towards
improving the rp experience.

(Mindustry mod)
